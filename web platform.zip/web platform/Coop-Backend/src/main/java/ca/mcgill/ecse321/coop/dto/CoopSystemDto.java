package ca.mcgill.ecse321.coop.dto;


import java.util.Set;

public class CoopSystemDto {
	
	
	public Set<String> eventNotificationsNames;

	public Set<String> coopJobsIds;

	public Set<String> messagesIds;

	

	public Set<String> coopUsersNames;

	
	public Set<String> documentsIds;

	

	public String id;


}
