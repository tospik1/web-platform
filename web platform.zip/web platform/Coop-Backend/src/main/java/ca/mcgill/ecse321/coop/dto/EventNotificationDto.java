package ca.mcgill.ecse321.coop.dto;


import java.sql.Date;
import java.sql.Time;

public class EventNotificationDto {
	
	
	public String coopSystemName;

	public String name;

	public String type;
	
	public String location;

	public Date date;

	
	public Time startTime;

	
	public Time endTime;
}
