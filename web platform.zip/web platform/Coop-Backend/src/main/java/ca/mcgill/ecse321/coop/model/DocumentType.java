package ca.mcgill.ecse321.coop.model;


public enum DocumentType {
	CV, Transcript, Contract, TaxCreditForm, ProofOfPlacement, Other, StudentEvaluationByEmployer, JobDetail
}
