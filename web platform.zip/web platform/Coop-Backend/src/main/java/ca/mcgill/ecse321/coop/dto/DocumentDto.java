package ca.mcgill.ecse321.coop.dto;


import java.sql.Time;
import java.sql.Date;
public class DocumentDto {

	public String type;

	
	public String coopSystemName;

	

	public Date submissionDate;

	

	public Time submissionTime;

	
	public String authorName;

	

	public int size;

	

	public String documentId;


}
