package ca.mcgill.ecse321.coop.model;


public enum CoopState {
	notYetStarted, started, interrupted, completed, studentGotOfferLaterFromSameEmployer
}
