package ca.mcgill.ecse321.coop.dto;





import java.sql.Date;

import java.util.Set;
public class CoopJobDto {
	
	
	public Set<String> coopJobDocumentsIds;

	
	public String coopSystemName;
	
	
	public String internName;


	public String name;

	public String description;

	public Date startDate;


	public Date endDate;
	
	
	public String employerName;

	public String state;

	
	public String jobId;



}
