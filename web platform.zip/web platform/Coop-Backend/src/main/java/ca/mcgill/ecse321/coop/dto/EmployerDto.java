package ca.mcgill.ecse321.coop.dto;




import java.util.Set;


public class EmployerDto extends CoopUserDto {

	
	public Set<String> coopJobsIds;

	public Set<String> eventNotificationsNames;
	
	public Set<String> archivedInternsNames;

}
