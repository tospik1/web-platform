package ca.mcgill.ecse321.coop.model;



public enum Event {
	conference, careeFair, presentation, Other
}
